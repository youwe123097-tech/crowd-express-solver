# Building the Crowd Express Solver APK

## Requirements
- Android Studio Hedgehog (2023.1.1) or newer  
  Download: https://developer.android.com/studio
- Android SDK 34 (installed automatically by Android Studio)

## Steps

1. **Open the project in Android Studio**
   - File → Open → select this folder (`artifacts/crowd-express-android`)
   - Let Gradle sync finish (takes ~2 min first time)

2. **Build the APK**
   - Menu: Build → Build Bundle(s) / APK(s) → Build APK(s)
   - Or from terminal inside this folder:
     ```
     ./gradlew assembleDebug
     ```
   - APK will be at: `app/build/outputs/apk/debug/app-debug.apk`

3. **Install on your phone**
   - Enable "Install unknown apps" on your phone:
     Settings → Apps → Special app access → Install unknown apps → Files → Allow
   - Transfer the APK to your phone (USB, Google Drive, etc.)
   - Tap the APK file on your phone to install

## First-time setup on phone

After installing, open the app and follow the 3-step setup:

1. **Grant Overlay Permission** — lets the button float over other apps
2. **Enable Accessibility Service** — find "Crowd Express Auto-Tap" in the list, toggle it on
3. **Tap START OVERLAY** — allow screen capture when prompted

Then open Crowd Express and tap the purple **SOLVE** button.

## API URL

The app talks to the deployed Replit API server for Claude vision analysis.  
Default URL is pre-filled. If you redeploy the Replit project, update it via  
"Edit API Server URL" in the app.
