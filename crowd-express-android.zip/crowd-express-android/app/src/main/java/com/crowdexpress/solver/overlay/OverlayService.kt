package com.crowdexpress.solver.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import com.crowdexpress.solver.MainActivity
import com.crowdexpress.solver.R
import com.crowdexpress.solver.accessibility.TapService
import com.crowdexpress.solver.solver.Solver
import com.crowdexpress.solver.vision.VisionClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import android.util.Base64

class OverlayService : Service() {

    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        const val CHANNEL_ID = "overlay_channel"
        const val NOTIF_ID = 1
        var isRunning = false
    }

    private lateinit var windowManager: WindowManager
    private var overlayView: View? = null
    private var overlayBtn: TextView? = null
    private lateinit var mediaProjection: MediaProjection
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val mainHandler = Handler(Looper.getMainLooper())

    // Drag state
    private var initialX = 0; private var initialY = 0
    private var initialTouchX = 0f; private var initialTouchY = 0f
    private var isDragging = false

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        startForeground(NOTIF_ID, buildNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, -1) ?: -1
        val resultData = intent?.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)

        if (resultCode != -1 && resultData != null) {
            val pm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            mediaProjection = pm.getMediaProjection(resultCode, resultData)
            showOverlay()
        }
        return START_STICKY
    }

    private fun showOverlay() {
        val inflater = LayoutInflater.from(this)
        overlayView = inflater.inflate(R.layout.overlay_button, null)
        overlayBtn = overlayView!!.findViewById(R.id.overlayBtn)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 20
            y = 300
        }

        overlayView!!.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x; initialY = params.y
                    initialTouchX = event.rawX; initialTouchY = event.rawY
                    isDragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX).toInt()
                    val dy = (event.rawY - initialTouchY).toInt()
                    if (Math.abs(dx) > 5 || Math.abs(dy) > 5) isDragging = true
                    params.x = initialX + dx
                    params.y = initialY + dy
                    windowManager.updateViewLayout(overlayView, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!isDragging) {
                        v.performClick()
                        onSolveTapped()
                    }
                    true
                }
                else -> false
            }
        }

        windowManager.addView(overlayView, params)
    }

    private fun onSolveTapped() {
        val btn = overlayBtn ?: return
        btn.text = "…"
        btn.isClickable = false
        btn.alpha = 0.7f

        scope.launch {
            try {
                // 1. Take screenshot
                val bitmap = captureScreen()
                if (bitmap == null) {
                    toast("Screenshot failed — check screen capture permission")
                    resetButton()
                    return@launch
                }

                btn.text = "AI…"

                // 2. Send to vision API
                val prefs = getSharedPreferences("crowd_express_prefs", Context.MODE_PRIVATE)
                val apiUrl = prefs.getString(getString(R.string.pref_api_url), "") ?: ""
                if (apiUrl.isEmpty()) {
                    toast("API URL not set — open Crowd Express Solver app to configure")
                    resetButton()
                    return@launch
                }

                val bos = ByteArrayOutputStream()
                bitmap.compress(Bitmap.CompressFormat.JPEG, 85, bos)
                val b64 = Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)

                val boardState = withContext(Dispatchers.IO) {
                    VisionClient.analyze(apiUrl, b64, "image/jpeg")
                }

                if (boardState == null) {
                    toast("Vision API failed — is the server running?")
                    resetButton()
                    return@launch
                }

                btn.text = "↯"

                // 3. Solve
                val solution = withContext(Dispatchers.Default) {
                    Solver.solve(boardState)
                }

                if (solution == null || solution.isEmpty()) {
                    toast("No solution found — board may need manual correction")
                    resetButton()
                    return@launch
                }

                btn.text = "▶"
                toast("Solving: ${solution.size} taps")

                // 4. Auto-tap each bus
                val tapService = TapService.instance
                if (tapService == null) {
                    toast("Accessibility service not running — enable it in settings")
                    resetButton()
                    return@launch
                }

                // Get the screen coordinates for each bus tap using the board layout
                val screenW = resources.displayMetrics.widthPixels
                val screenH = resources.displayMetrics.heightPixels
                val taps = Solver.solutionToScreenCoords(boardState, solution, screenW, screenH)

                for ((index, tap) in taps.withIndex()) {
                    btn.text = "${index + 1}/${taps.size}"
                    tapService.performTap(tap.first, tap.second)
                    delay(600) // wait for animation to finish
                }

                btn.text = "✓"
                toast("Done! Puzzle solved in ${solution.size} taps")
                delay(2000)
                resetButton()

            } catch (e: Exception) {
                toast("Error: ${e.message}")
                resetButton()
            }
        }
    }

    private suspend fun captureScreen(): Bitmap? = withContext(Dispatchers.IO) {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)

        val imageReader = ImageReader.newInstance(
            metrics.widthPixels, metrics.heightPixels,
            PixelFormat.RGBA_8888, 2
        )

        val virtualDisplay = mediaProjection.createVirtualDisplay(
            "CrowdExpressCapture",
            metrics.widthPixels, metrics.heightPixels, metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader.surface, null, null
        )

        // Give the display time to render
        delay(200)

        val image = imageReader.acquireLatestImage()
        val bitmap = if (image != null) {
            val planes = image.planes
            val buffer = planes[0].buffer
            val pixelStride = planes[0].pixelStride
            val rowStride = planes[0].rowStride
            val rowPadding = rowStride - pixelStride * metrics.widthPixels
            val bmp = Bitmap.createBitmap(
                metrics.widthPixels + rowPadding / pixelStride,
                metrics.heightPixels,
                Bitmap.Config.ARGB_8888
            )
            bmp.copyPixelsFromBuffer(buffer)
            image.close()
            Bitmap.createBitmap(bmp, 0, 0, metrics.widthPixels, metrics.heightPixels)
        } else null

        imageReader.close()
        virtualDisplay.release()
        bitmap
    }

    private fun resetButton() {
        mainHandler.post {
            overlayBtn?.text = "SOLVE"
            overlayBtn?.isClickable = true
            overlayBtn?.alpha = 1f
        }
    }

    private fun toast(msg: String) {
        mainHandler.post { Toast.makeText(this@OverlayService, msg, Toast.LENGTH_SHORT).show() }
    }

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        scope.cancel()
        overlayView?.let { windowManager.removeView(it) }
        if (::mediaProjection.isInitialized) mediaProjection.stop()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.channel_name),
            NotificationManager.IMPORTANCE_LOW
        ).apply { description = getString(R.string.channel_description) }
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        val pi = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Crowd Express Solver")
            .setContentText("Overlay active — tap SOLVE over the game")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }
}
