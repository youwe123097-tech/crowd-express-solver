package com.crowdexpress.solver.vision

import com.crowdexpress.solver.solver.BoardState
import com.crowdexpress.solver.solver.BusDef
import com.crowdexpress.solver.solver.CrowdDef
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object VisionClient {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    /**
     * Sends a base64-encoded image to the vision API and returns a parsed BoardState,
     * or null on any failure.
     */
    fun analyze(apiBaseUrl: String, imageBase64: String, mediaType: String): BoardState? {
        return try {
            val body = JSONObject().apply {
                put("imageBase64", imageBase64)
                put("mediaType", mediaType)
            }.toString()

            val request = Request.Builder()
                .url("$apiBaseUrl/api/vision/analyze")
                .post(body.toRequestBody("application/json".toMediaType()))
                .build()

            val response = client.newCall(request).execute()
            if (!response.isSuccessful) return null

            val json = JSONObject(response.body?.string() ?: return null)
            parseBoardState(json)
        } catch (e: Exception) {
            null
        }
    }

    private fun parseBoardState(json: JSONObject): BoardState {
        val busesArr = json.getJSONArray("buses")
        val crowdsArr = json.getJSONArray("crowds")

        val buses = mutableListOf<BusDef>()
        for (i in 0 until busesArr.length()) {
            val b = busesArr.getJSONObject(i)
            buses.add(BusDef(
                id = b.getString("id"),
                color = b.getString("color"),
                direction = b.getString("direction"),
                lane = b.getInt("lane"),
                position = b.getInt("position"),
                type = b.getString("type"),
                stickyPartner = b.optString("sticky_partner").takeIf { it.isNotEmpty() },
                arrowTarget = b.optString("arrow_target").takeIf { it.isNotEmpty() },
                arrowDir = b.optString("arrow_dir").takeIf { it.isNotEmpty() },
                lockColor = b.optString("lock_color").takeIf { it.isNotEmpty() },
                keyColor = b.optString("key_color").takeIf { it.isNotEmpty() },
                maxMoves = if (b.has("max_moves") && !b.isNull("max_moves")) b.getInt("max_moves") else null
            ))
        }

        val crowds = mutableListOf<CrowdDef>()
        for (i in 0 until crowdsArr.length()) {
            val c = crowdsArr.getJSONObject(i)
            crowds.add(CrowdDef(
                id = c.getString("id"),
                color = c.getString("color"),
                direction = c.getString("direction"),
                lane = c.getInt("lane")
            ))
        }

        return BoardState(buses, crowds)
    }
}
