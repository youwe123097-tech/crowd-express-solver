package com.crowdexpress.solver.solver

object Rules {

    fun legalTaps(state: GameState): List<String> {
        return state.specs.keys.filter { busId ->
            val bs = state.busStates[busId] ?: return@filter false
            if (!bs.active) return@filter false
            canTap(state, busId)
        }
    }

    fun canTap(state: GameState, busId: String): Boolean {
        val spec = state.specs[busId] ?: return false
        val bs = state.busStates[busId] ?: return false
        if (!bs.active) return false

        // FROZEN: must have nothing in front in the same lane
        if (spec.busType == "FROZEN" && isBlocked(state, busId)) return false

        // LOCKED: must be unlocked
        if (spec.busType == "LOCKED" && !bs.unlocked) return false

        // LIMITED: must have moves remaining
        if (spec.busType == "LIMITED") {
            val max = spec.maxMoves ?: 2
            if (bs.movesUsed >= max) return false
        }

        return true
    }

    fun applyTap(state: GameState, busId: String): GameState? {
        if (!canTap(state, busId)) return null
        val spec = state.specs[busId] ?: return null
        val bs = state.busStates[busId] ?: return null

        val newBusStates = state.busStates.toMutableMap()
        val newUsedKeys = state.usedKeys.toMutableSet()

        fun advanceBus(id: String) {
            val s = newBusStates[id] ?: return
            val sp = state.specs[id] ?: return
            if (s.position == 0) {
                // Exit
                newBusStates[id] = s.copy(active = false)
                // KEY: unlock its target
                if (sp.busType == "KEY") {
                    val keyColor = sp.keyColor ?: sp.color
                    newUsedKeys.add(keyColor)
                    // Unlock any LOCKED buses with matching lockColor
                    for ((lid, ls) in newBusStates) {
                        val lspec = state.specs[lid] ?: continue
                        if (lspec.busType == "LOCKED" && (lspec.lockColor ?: lspec.color) == keyColor) {
                            newBusStates[lid] = ls.copy(unlocked = true)
                        }
                    }
                }
            } else {
                newBusStates[id] = s.copy(
                    position = s.position - 1,
                    movesUsed = s.movesUsed + 1
                )
            }
        }

        when (spec.busType) {
            "STICKY" -> {
                // Move both this bus and its partner together
                advanceBus(busId)
                spec.stickyPartner?.let { advanceBus(it) }
            }
            "ARROW" -> {
                // Move this bus, then push target forward one step
                advanceBus(busId)
                spec.arrowTarget?.let { targetId ->
                    val tbs = newBusStates[targetId]
                    if (tbs != null && tbs.active && tbs.position > 0) {
                        newBusStates[targetId] = tbs.copy(position = tbs.position - 1)
                    }
                }
            }
            else -> advanceBus(busId)
        }

        return state.copy(
            busStates = newBusStates,
            usedKeys = newUsedKeys,
            tapHistory = state.tapHistory + busId
        )
    }

    fun isSolved(state: GameState): Boolean {
        return state.busStates.values.none { it.active }
    }

    private fun isBlocked(state: GameState, busId: String): Boolean {
        val spec = state.specs[busId] ?: return false
        val pos = state.busStates[busId]?.position ?: return false
        for ((bid2, spec2) in state.specs) {
            if (bid2 == busId) continue
            val bs2 = state.busStates[bid2] ?: continue
            if (spec2.lane == spec.lane && bs2.active && bs2.position < pos) return true
        }
        return false
    }

    fun crowdAccepts(state: GameState, busId: String): Boolean {
        val spec = state.specs[busId] ?: return false
        return state.crowds.any { c -> c.direction == spec.direction && c.lane == spec.lane && c.color == spec.color }
    }
}
