package com.crowdexpress.solver.solver

data class BusDef(
    val id: String,
    val color: String,
    val direction: String,
    val lane: Int,
    val position: Int,
    val type: String,           // NORMAL | FROZEN | LOCKED | KEY | STICKY | ARROW | LIMITED
    val stickyPartner: String? = null,
    val arrowTarget: String? = null,
    val arrowDir: String? = null,
    val lockColor: String? = null,
    val keyColor: String? = null,
    val maxMoves: Int? = null
)

data class CrowdDef(
    val id: String,
    val color: String,
    val direction: String,
    val lane: Int
)

data class BoardState(
    val buses: List<BusDef>,
    val crowds: List<CrowdDef>
)

// ─── Internal solver types ────────────────────────────────────────────────────

data class BusSpec(
    val busId: String,
    val color: String,
    val direction: String,
    val lane: Int,
    val busType: String,
    val stickyPartner: String? = null,
    val arrowTarget: String? = null,
    val arrowDir: String? = null,
    val lockColor: String? = null,
    val keyColor: String? = null,
    val maxMoves: Int? = null
)

data class BusState(
    val busId: String,
    val position: Int,
    val active: Boolean,
    val unlocked: Boolean,
    val movesUsed: Int
)

data class GameState(
    val specs: Map<String, BusSpec>,
    val crowds: List<CrowdDef>,
    val busStates: Map<String, BusState>,
    val usedKeys: Set<String>,
    val tapHistory: List<String>
)
