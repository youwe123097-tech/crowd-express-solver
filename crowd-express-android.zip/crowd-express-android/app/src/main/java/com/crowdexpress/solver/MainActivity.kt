package com.crowdexpress.solver

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.crowdexpress.solver.databinding.ActivityMainBinding
import com.crowdexpress.solver.overlay.OverlayService

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: SharedPreferences
    private lateinit var projectionManager: MediaProjectionManager

    // Launcher for MediaProjection permission
    private val projectionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK && result.data != null) {
            startOverlayService(result.resultCode, result.data!!)
        } else {
            Toast.makeText(this, "Screen capture permission denied — overlay cannot take screenshots", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = getSharedPreferences("crowd_express_prefs", Context.MODE_PRIVATE)
        projectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        // Default API URL to the published Replit app
        if (prefs.getString(getString(R.string.pref_api_url), null) == null) {
            prefs.edit().putString(
                getString(R.string.pref_api_url),
                "https://536520aa-93a9-4251-977a-7f50a90f01e2-00-24lr1dfwp2lme.replit.app"
            ).apply()
        }

        setupUI()
        updateStatus()
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun setupUI() {
        binding.btnGrantOverlay.setOnClickListener { requestOverlayPermission() }
        binding.btnGrantAccessibility.setOnClickListener { requestAccessibilityPermission() }
        binding.btnStartOverlay.setOnClickListener { requestScreenCapture() }
        binding.btnStopOverlay.setOnClickListener { stopOverlayService() }

        binding.btnEditApiUrl.setOnClickListener {
            val currentUrl = prefs.getString(getString(R.string.pref_api_url), "") ?: ""
            val input = android.widget.EditText(this).apply {
                setText(currentUrl)
                hint = "https://your-api-url.replit.app"
            }
            AlertDialog.Builder(this)
                .setTitle("API Server URL")
                .setMessage("Enter the base URL of your deployed Replit API server.")
                .setView(input)
                .setPositiveButton("Save") { _, _ ->
                    val url = input.text.toString().trimEnd('/')
                    prefs.edit().putString(getString(R.string.pref_api_url), url).apply()
                    Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
                    updateStatus()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    private fun updateStatus() {
        val overlayOk = Settings.canDrawOverlays(this)
        val accessibilityOk = isAccessibilityEnabled()
        val serviceRunning = OverlayService.isRunning
        val apiUrl = prefs.getString(getString(R.string.pref_api_url), "") ?: ""

        binding.statusOverlay.text = if (overlayOk) "✅ Overlay permission granted" else "❌ Overlay permission needed"
        binding.statusAccessibility.text = if (accessibilityOk) "✅ Accessibility service enabled" else "❌ Accessibility service needed"
        binding.statusService.text = if (serviceRunning) "✅ Overlay is running" else "⭕ Overlay not started"
        binding.statusApiUrl.text = "API: ${apiUrl.ifEmpty { "not set" }}"

        binding.btnGrantOverlay.isEnabled = !overlayOk
        binding.btnGrantAccessibility.isEnabled = !accessibilityOk
        binding.btnStartOverlay.isEnabled = overlayOk && accessibilityOk && !serviceRunning
        binding.btnStopOverlay.isEnabled = serviceRunning

        binding.instructionText.text = when {
            !overlayOk -> "Step 1: Grant overlay permission above."
            !accessibilityOk -> "Step 2: Enable the accessibility service above."
            !serviceRunning -> "Step 3: Tap START OVERLAY, then open Crowd Express."
            else -> "Overlay active! Open Crowd Express and tap the purple SOLVE button."
        }
    }

    private fun requestOverlayPermission() {
        try {
            // First try: direct to this app's overlay setting
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            startActivity(intent)
        } catch (e: Exception) {
            try {
                // Fallback: open general overlay list (user taps app manually)
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION))
            } catch (e2: Exception) {
                // Last resort: open app details
                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                startActivity(intent)
            }
        }
    }

    private fun requestAccessibilityPermission() {
        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
    }

    private fun requestScreenCapture() {
        projectionLauncher.launch(projectionManager.createScreenCaptureIntent())
    }

    private fun startOverlayService(resultCode: Int, data: Intent) {
        val intent = Intent(this, OverlayService::class.java).apply {
            putExtra(OverlayService.EXTRA_RESULT_CODE, resultCode)
            putExtra(OverlayService.EXTRA_RESULT_DATA, data)
        }
        startForegroundService(intent)
        updateStatus()
        Toast.makeText(this, "Overlay started! Switch to Crowd Express.", Toast.LENGTH_LONG).show()
        // Move app to background so user can switch to the game
        moveTaskToBack(true)
    }

    private fun stopOverlayService() {
        stopService(Intent(this, OverlayService::class.java))
        updateStatus()
    }

    private fun isAccessibilityEnabled(): Boolean {
        val am = getSystemService(ACCESSIBILITY_SERVICE) as AccessibilityManager
        val enabledServices = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabledServices.contains("${packageName}/${packageName}.accessibility.TapService")
    }
}
