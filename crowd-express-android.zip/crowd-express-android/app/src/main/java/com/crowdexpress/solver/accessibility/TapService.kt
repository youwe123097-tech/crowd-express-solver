package com.crowdexpress.solver.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

/**
 * Accessibility service that performs programmatic taps at given screen coordinates.
 * Android requires this service to simulate touch gestures — it cannot be done any other way.
 */
class TapService : AccessibilityService() {

    companion object {
        /** Singleton reference set on service connect/disconnect */
        var instance: TapService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // We only need gesture dispatch — no event processing required
    }

    override fun onInterrupt() {}

    /**
     * Dispatches a tap gesture at the given screen coordinates.
     * Uses GestureDescription which works on API 24+ and does not require root.
     */
    fun performTap(x: Float, y: Float, callback: (() -> Unit)? = null) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 100)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription) {
                callback?.invoke()
            }
            override fun onCancelled(gestureDescription: GestureDescription) {
                callback?.invoke()
            }
        }, null)
    }
}
