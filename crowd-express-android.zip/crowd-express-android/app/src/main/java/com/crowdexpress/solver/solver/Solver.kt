package com.crowdexpress.solver.solver

import java.util.PriorityQueue

object Solver {

    private const val MAX_STATES = 20000

    /**
     * Build a GameState from the parsed BoardState and run A* search.
     * Returns ordered list of bus IDs to tap, or null if no solution found.
     */
    fun solve(board: BoardState): List<String>? {
        val state = buildGameState(board) ?: return null
        if (Rules.isSolved(state)) return emptyList()

        data class Node(
            val g: Int,
            val h: Int,
            val state: GameState,
            val parent: Node?,
            val tapId: String?
        ) : Comparable<Node> {
            override fun compareTo(other: Node) = (g + h).compareTo(other.g + other.h)
                .let { if (it != 0) it else g.compareTo(other.g) }
        }

        val open = PriorityQueue<Node>()
        val seen = HashSet<String>()

        open.add(Node(0, heuristic(state), state, null, null))

        var iterations = 0
        while (open.isNotEmpty() && iterations < MAX_STATES) {
            iterations++
            val node = open.poll() ?: break

            val fp = fingerprint(node.state)
            if (!seen.add(fp)) continue

            if (Rules.isSolved(node.state)) {
                // Reconstruct path
                val path = mutableListOf<String>()
                var cur: Node? = node
                while (cur?.tapId != null) {
                    val tapId = cur.tapId
                    if (tapId != null) path.add(tapId)
                    cur = cur.parent
                }
                return path.reversed()
            }

            for (tapId in Rules.legalTaps(node.state)) {
                val next = Rules.applyTap(node.state, tapId) ?: continue
                val nextFp = fingerprint(next)
                if (nextFp in seen) continue
                open.add(Node(node.g + 1, heuristic(next), next, node, tapId))
            }
        }

        return null
    }

    private fun buildGameState(board: BoardState): GameState? {
        val specs = mutableMapOf<String, BusSpec>()
        val busStates = mutableMapOf<String, BusState>()

        for (b in board.buses) {
            specs[b.id] = BusSpec(
                busId = b.id,
                color = b.color,
                direction = b.direction,
                lane = b.lane,
                busType = b.type,
                stickyPartner = b.stickyPartner,
                arrowTarget = b.arrowTarget,
                arrowDir = b.arrowDir,
                lockColor = b.lockColor,
                keyColor = b.keyColor,
                maxMoves = b.maxMoves
            )
            busStates[b.id] = BusState(
                busId = b.id,
                position = b.position,
                active = true,
                unlocked = b.type != "LOCKED",
                movesUsed = 0
            )
        }

        return GameState(
            specs = specs,
            crowds = board.crowds,
            busStates = busStates,
            usedKeys = emptySet(),
            tapHistory = emptyList()
        )
    }

    /**
     * Convert a solution (ordered bus IDs) to screen tap coordinates.
     *
     * Crowd Express uses a grid layout. We estimate each bus's on-screen position
     * by its lane and current position in the board. The board typically occupies
     * the central portion of the screen with some padding.
     *
     * This is an approximation — if taps land slightly off, the user can adjust
     * the BOARD_* constants in a settings screen (future improvement).
     */
    fun solutionToScreenCoords(
        board: BoardState,
        solution: List<String>,
        screenW: Int,
        screenH: Int
    ): List<Pair<Float, Float>> {
        // Estimate grid bounds (Crowd Express typically centres the board with top padding)
        val boardTop = screenH * 0.18f      // ~18% from top (past score/header)
        val boardBottom = screenH * 0.82f   // ~82% (above bottom UI)
        val boardLeft = screenW * 0.05f
        val boardRight = screenW * 0.95f

        val boardH = boardBottom - boardTop
        val boardW = boardRight - boardLeft

        // Detect grid size from lane/position extremes
        val maxLane = (board.buses.maxOfOrNull { it.lane } ?: 0).coerceAtLeast(4)
        val maxPos = (board.buses.maxOfOrNull { it.position } ?: 0).coerceAtLeast(3)
        val cols = maxPos + 1
        val rows = maxLane + 1

        val cellW = boardW / cols
        val cellH = boardH / rows

        // Build a map of busId → BusDef for coordinate lookup
        val busMap = board.buses.associateBy { it.id }

        // Replay the solution to track positions as taps are applied
        var state: GameState? = buildGameState(board)

        return solution.mapNotNull { busId ->
            val spec = busMap[busId]
            val bs = state?.busStates?.get(busId)
            val coord = if (spec != null && bs != null) {
                val isHorizontal = spec.direction == "left" || spec.direction == "right"
                val cx: Float
                val cy: Float
                if (isHorizontal) {
                    // Lane = row, position = column from right/left
                    cy = boardTop + (spec.lane + 0.5f) * cellH
                    cx = if (spec.direction == "right") {
                        boardLeft + (bs.position + 0.5f) * cellW
                    } else {
                        boardRight - (bs.position + 0.5f) * cellW
                    }
                } else {
                    // Lane = column, position = row from top/bottom
                    cx = boardLeft + (spec.lane + 0.5f) * cellW
                    cy = if (spec.direction == "down") {
                        boardTop + (bs.position + 0.5f) * cellH
                    } else {
                        boardBottom - (bs.position + 0.5f) * cellH
                    }
                }
                Pair(cx, cy)
            } else null

            // Advance state
            state = state?.let { Rules.applyTap(it, busId) }
            coord
        }
    }

    private fun heuristic(state: GameState) = state.busStates.values.count { it.active }

    private fun fingerprint(state: GameState): String {
        val parts = state.busStates.entries
            .sortedBy { it.key }
            .joinToString("|") { (id, bs) -> "$id:${bs.position}:${if (bs.active) 1 else 0}:${if (bs.unlocked) 1 else 0}:${bs.movesUsed}" }
        return "$parts#${state.usedKeys.sorted().joinToString(",")}"
    }
}
